/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("recipes");

  const record0 = new Record(collection);
    record0.set("name", "Brownies de Chocolate Caseros");
    record0.set("description", "Un postre cl\u00e1sico que nunca falla. Estos brownies de chocolate son suaves, h\u00famedos y con un intenso sabor a cacao. Perfectos para una tarde de antojo, una reuni\u00f3n con amigos o simplemente para consentirte con algo dulce.");
    record0.set("cuisine", "Postre");
    record0.set("difficulty", "easy");
    record0.set("cookingTime", 40);
    record0.set("ingredients", [{"item": "120 g de mantequilla", "amount": "120", "unit": "g"}, {"item": "200 g de chocolate semiamargo", "amount": "200", "unit": "g"}, {"item": "2 huevos", "amount": "2", "unit": "unidad"}, {"item": "150 g de az\u00facar", "amount": "150", "unit": "g"}, {"item": "1 cucharadita de esencia de vainilla", "amount": "1", "unit": "cucharadita"}, {"item": "90 g de harina", "amount": "90", "unit": "g"}, {"item": "30 g de cocoa en polvo", "amount": "30", "unit": "g"}, {"item": "1 pizca de sal", "amount": "1", "unit": "pizca"}, {"item": "Chispas de chocolate o nueces (opcional)", "amount": "al gusto", "unit": "opcional"}]);
    record0.set("steps", [{"step": 1, "instruction": "Precalienta el horno a 180 \u00b0C."}, {"step": 2, "instruction": "Derrite la mantequilla junto con el chocolate hasta obtener una mezcla homog\u00e9nea."}, {"step": 3, "instruction": "Bate los huevos con el az\u00facar hasta que la mezcla se vea ligera."}, {"step": 4, "instruction": "Incorpora la vainilla y agrega la mezcla de chocolate."}, {"step": 5, "instruction": "A\u00f1ade la harina, cocoa y sal. Mezcla suavemente."}, {"step": 6, "instruction": "Vierte en un molde cuadrado previamente engrasado."}, {"step": 7, "instruction": "Hornea durante 25 minutos."}, {"step": 8, "instruction": "Deja enfriar y corta en cuadritos."}]);
    const record0_createdByLookup = app.findFirstRecordByFilter("users", "id != ''");
    if (!record0_createdByLookup) { throw new Error("Lookup failed for createdBy: no record in 'users' matching \"id != ''\""); }
    record0.set("createdBy", record0_createdByLookup.id);
  try {
    app.save(record0);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record1 = new Record(collection);
    record1.set("name", "Cheesecake de Fresa sin Horno");
    record1.set("description", "Un postre fresco, cremoso y perfecto para cualquier ocasi\u00f3n. Este cheesecake de fresa sin horno combina una base crujiente de galleta con un relleno suave y un toque frutal irresistible. Ideal para d\u00edas calurosos o cuando quieres un postre elegante y f\u00e1cil.");
    record1.set("cuisine", "Postre");
    record1.set("difficulty", "medium");
    record1.set("cookingTime", 260);
    record1.set("ingredients", [{"item": "200 g de galletas tipo Mar\u00eda", "amount": "200", "unit": "g"}, {"item": "90 g de mantequilla derretida", "amount": "90", "unit": "g"}, {"item": "400 g de queso crema", "amount": "400", "unit": "g"}, {"item": "200 ml de crema para batir", "amount": "200", "unit": "ml"}, {"item": "100 g de az\u00facar", "amount": "100", "unit": "g"}, {"item": "1 cucharadita de vainilla", "amount": "1", "unit": "cucharadita"}, {"item": "10 g de grenetina sin sabor", "amount": "10", "unit": "g"}, {"item": "50 ml de agua", "amount": "50", "unit": "ml"}, {"item": "200 g de fresas", "amount": "200", "unit": "g"}, {"item": "2 cucharadas de az\u00facar", "amount": "2", "unit": "cucharada"}, {"item": "Fresas enteras para decorar", "amount": "al gusto", "unit": "opcional"}]);
    record1.set("steps", [{"step": 1, "instruction": "Tritura las galletas hasta obtener migas finas."}, {"step": 2, "instruction": "Mezcla con la mantequilla derretida y presiona en el fondo de un molde desmontable. Refrigera 15 minutos."}, {"step": 3, "instruction": "Bate el queso crema con el az\u00facar y la vainilla hasta que quede suave."}, {"step": 4, "instruction": "Hidrata la grenetina con el agua y cali\u00e9ntala unos segundos hasta que se disuelva. Agr\u00e9gala a la mezcla."}, {"step": 5, "instruction": "Incorpora la crema para batir previamente montada con movimientos envolventes."}, {"step": 6, "instruction": "Vierte la mezcla sobre la base de galleta y refrigera por 4 horas."}, {"step": 7, "instruction": "Cocina las fresas con el az\u00facar por 5 minutos para hacer una salsa ligera."}, {"step": 8, "instruction": "Decora con la salsa y fresas frescas antes de servir."}]);
    const record1_createdByLookup = app.findFirstRecordByFilter("users", "id != ''");
    if (!record1_createdByLookup) { throw new Error("Lookup failed for createdBy: no record in 'users' matching \"id != ''\""); }
    record1.set("createdBy", record1_createdByLookup.id);
  try {
    app.save(record1);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record2 = new Record(collection);
    record2.set("name", "Tiramis\u00fa Italiano Cl\u00e1sico");
    record2.set("description", "El tiramis\u00fa es uno de los postres m\u00e1s famosos de Italia. Suave, cremoso y con un delicioso sabor a caf\u00e9, este cl\u00e1sico combina capas de galletas remojadas con una mezcla de queso mascarpone y cocoa. Es perfecto para ocasiones especiales o para darle a tu p\u00e1gina un toque internacional y sofisticado.");
    record2.set("cuisine", "Postre");
    record2.set("difficulty", "medium");
    record2.set("cookingTime", 265);
    record2.set("ingredients", [{"item": "250 g de queso mascarpone", "amount": "250", "unit": "g"}, {"item": "200 ml de crema para batir", "amount": "200", "unit": "ml"}, {"item": "3 cucharadas de az\u00facar", "amount": "3", "unit": "cucharada"}, {"item": "1 cucharadita de vainilla", "amount": "1", "unit": "cucharadita"}, {"item": "1 taza de caf\u00e9 espresso fr\u00edo", "amount": "1", "unit": "taza"}, {"item": "1 paquete de galletas tipo ladyfingers", "amount": "1", "unit": "paquete"}, {"item": "Cocoa en polvo para decorar", "amount": "al gusto", "unit": "opcional"}, {"item": "Chocolate rallado (opcional)", "amount": "al gusto", "unit": "opcional"}]);
    record2.set("steps", [{"step": 1, "instruction": "Bate la crema para batir junto con el az\u00facar hasta que espese."}, {"step": 2, "instruction": "Incorpora el queso mascarpone y la vainilla, mezclando suavemente hasta obtener una crema homog\u00e9nea."}, {"step": 3, "instruction": "Remoja r\u00e1pidamente las galletas en el caf\u00e9 fr\u00edo, cuidando que no se deshagan."}, {"step": 4, "instruction": "Coloca una capa de galletas en el fondo de un molde o recipiente de vidrio."}, {"step": 5, "instruction": "A\u00f1ade una capa de la mezcla cremosa encima."}, {"step": 6, "instruction": "Repite el proceso formando varias capas, terminando con crema."}, {"step": 7, "instruction": "Espolvorea cocoa en polvo sobre la \u00faltima capa."}, {"step": 8, "instruction": "Refrigera durante al menos 4 horas antes de servir."}]);
    const record2_createdByLookup = app.findFirstRecordByFilter("users", "id != ''");
    if (!record2_createdByLookup) { throw new Error("Lookup failed for createdBy: no record in 'users' matching \"id != ''\""); }
    record2.set("createdBy", record2_createdByLookup.id);
  try {
    app.save(record2);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record3 = new Record(collection);
    record3.set("name", "Mochi Japon\u00e9s de Fresa");
    record3.set("description", "El mochi es un postre tradicional japon\u00e9s elaborado con harina de arroz glutinoso, conocido por su textura suave, el\u00e1stica y ligeramente pegajosa. Esta versi\u00f3n rellena de fresa fresca y crema dulce es perfecta para darle a tu p\u00e1gina un estilo internacional, delicado y muy aesthetic.");
    record3.set("cuisine", "Postre");
    record3.set("difficulty", "medium");
    record3.set("cookingTime", 50);
    record3.set("ingredients", [{"item": "1 taza de harina de arroz glutinoso", "amount": "1", "unit": "taza"}, {"item": "1/4 taza de az\u00facar", "amount": "0.25", "unit": "taza"}, {"item": "3/4 taza de agua", "amount": "0.75", "unit": "taza"}, {"item": "F\u00e9cula de ma\u00edz para espolvorear", "amount": "al gusto", "unit": "opcional"}, {"item": "6 fresas medianas", "amount": "6", "unit": "unidad"}, {"item": "100 ml de crema batida o crema chantilly", "amount": "100", "unit": "ml"}]);
    record3.set("steps", [{"step": 1, "instruction": "Mezcla la harina de arroz, el az\u00facar y el agua en un recipiente apto para microondas hasta que no queden grumos."}, {"step": 2, "instruction": "Cocina en el microondas durante 1 minuto, mezcla y vuelve a cocinar por 1 minuto m\u00e1s. Repite hasta que la masa est\u00e9 transl\u00facida y el\u00e1stica."}, {"step": 3, "instruction": "Espolvorea una superficie con f\u00e9cula de ma\u00edz para evitar que se pegue."}, {"step": 4, "instruction": "Coloca la masa encima y deja enfriar unos minutos."}, {"step": 5, "instruction": "Divide en 6 porciones peque\u00f1as y est\u00edralas en forma de c\u00edrculo."}, {"step": 6, "instruction": "Rellena cada c\u00edrculo con un poco de crema batida y una fresa en el centro."}, {"step": 7, "instruction": "Cierra cuidadosamente formando una bolita."}, {"step": 8, "instruction": "Refrigera durante 30 minutos antes de servir."}]);
    const record3_createdByLookup = app.findFirstRecordByFilter("users", "id != ''");
    if (!record3_createdByLookup) { throw new Error("Lookup failed for createdBy: no record in 'users' matching \"id != ''\""); }
    record3.set("createdBy", record3_createdByLookup.id);
  try {
    app.save(record3);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record4 = new Record(collection);
    record4.set("name", "Flan Napolitano");
    record4.set("description", "El flan napolitano es un postre cl\u00e1sico, cremoso y delicioso, famoso por su textura suave y su irresistible capa de caramelo. Preparado con queso crema, leche condensada y vainilla, es perfecto para cualquier ocasi\u00f3n y un favorito en la cocina mexicana.");
    record4.set("cuisine", "Postre");
    record4.set("difficulty", "medium");
    record4.set("cookingTime", 195);
    record4.set("ingredients", [{"item": "1 taza de az\u00facar", "amount": "1", "unit": "taza"}, {"item": "1/4 taza de agua", "amount": "0.25", "unit": "taza"}, {"item": "1 lata de leche condensada", "amount": "1", "unit": "lata"}, {"item": "1 lata de leche evaporada", "amount": "1", "unit": "lata"}, {"item": "190 g de queso crema", "amount": "190", "unit": "g"}, {"item": "5 huevos", "amount": "5", "unit": "unidad"}, {"item": "1 cucharadita de vainilla", "amount": "1", "unit": "cucharadita"}]);
    record4.set("steps", [{"step": 1, "instruction": "Precalienta el horno a 180 \u00b0C."}, {"step": 2, "instruction": "Prepara el caramelo calentando el az\u00facar con el agua a fuego medio hasta obtener un color dorado \u00e1mbar."}, {"step": 3, "instruction": "Vierte el caramelo en el fondo del molde para flan y distrib\u00fayelo con cuidado."}, {"step": 4, "instruction": "Lic\u00faa la leche condensada, la leche evaporada, el queso crema, los huevos y la vainilla hasta obtener una mezcla suave."}, {"step": 5, "instruction": "Vierte la mezcla en el molde sobre el caramelo."}, {"step": 6, "instruction": "Coloca el molde en una charola con agua caliente para hornear a ba\u00f1o mar\u00eda."}, {"step": 7, "instruction": "Hornea durante 1 hora o hasta que al insertar un cuchillo salga limpio."}, {"step": 8, "instruction": "Deja enfriar a temperatura ambiente y luego refrigera por al menos 2 horas."}, {"step": 9, "instruction": "Desmolda con cuidado sobre un plato grande antes de servir."}]);
    const record4_createdByLookup = app.findFirstRecordByFilter("users", "id != ''");
    if (!record4_createdByLookup) { throw new Error("Lookup failed for createdBy: no record in 'users' matching \"id != ''\""); }
    record4.set("createdBy", record4_createdByLookup.id);
  try {
    app.save(record4);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }
}, (app) => {
  // Rollback: record IDs not known, manual cleanup needed
})
